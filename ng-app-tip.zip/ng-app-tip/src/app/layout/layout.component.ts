import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-layout',
  template:
  `
  <app-header></app-header>
  <app-sidebar></app-sidebar>
  <section class="main-container">
    <router-outlet></router-outlet>
  </section>
  `
})
export class LayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
